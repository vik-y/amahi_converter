OC.L10N.register(
    "encryption",
    {
    "The share will expire on %s." : "Gildistími deilingar rennur út %s.",
    "Cheers!" : "Skál!",
    "Enabled" : "Virkt",
    "Disabled" : "Óvirkt"
},
"nplurals=2; plural=(n % 10 != 1 || n % 100 == 11);");
