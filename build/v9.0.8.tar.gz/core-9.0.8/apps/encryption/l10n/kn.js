OC.L10N.register(
    "encryption",
    {
    "Cheers!" : "ಆನಂದಿಸಿ !",
    "Enabled" : "ಸಕ್ರಿಯಗೊಳಿಸಿದೆ",
    "Disabled" : "ನಿಷ್ಕ್ರಿಯಗೊಳಿಸಲಾಗಿದೆ"
},
"nplurals=1; plural=0;");
