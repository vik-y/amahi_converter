OC.L10N.register(
    "comments",
    {
    "Cancel" : "Mégsem",
    "Save" : "Mentés",
    "Comment" : "Komment",
    "<strong>Comments</strong> for files" : "<strong>Hozzászólások</strong> a fájlokhoz",
    "Delete comment" : "Hozzászólás törlése",
    "Edit comment" : "Hozzászólás szerkesztése",
    "No other comments available" : "Nincs több hozzászólás.",
    "Post" : "Küldés"
},
"nplurals=2; plural=(n != 1);");
