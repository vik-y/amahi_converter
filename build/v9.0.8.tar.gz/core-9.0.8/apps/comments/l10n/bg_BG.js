OC.L10N.register(
    "comments",
    {
    "Cancel" : "Отказ",
    "Save" : "Запазване",
    "Comment" : "Коментар"
},
"nplurals=2; plural=(n != 1);");
