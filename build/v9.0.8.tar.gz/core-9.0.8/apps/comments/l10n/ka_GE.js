OC.L10N.register(
    "comments",
    {
    "Cancel" : "უარყოფა",
    "Save" : "შენახვა"
},
"nplurals=1; plural=0;");
