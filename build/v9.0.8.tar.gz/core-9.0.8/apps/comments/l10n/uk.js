OC.L10N.register(
    "comments",
    {
    "<strong>Comments</strong> for files" : "<strong>Коментарі</strong> до файлів",
    "%1$s commented" : "%1$s прокоментовано",
    "%1$s commented on %2$s" : "%1$s прокоментовано у %2$s",
    "Comments" : "Коментарі",
    "Type in a new comment..." : "Введіть новий коментар...",
    "Delete comment" : "Видалити коментар",
    "Post" : "Відправити",
    "Cancel" : "Скасувати",
    "Edit comment" : "Редагувати коментар",
    "[Deleted user]" : "[Видалений користувач]",
    "No other comments available" : "Інші коментарі не доступні",
    "More comments..." : "Більше коментарів...",
    "Save" : "Зберегти",
    "Allowed characters {count} of {max}" : "Доступно символів {count} з {max}",
    "{count} unread comments" : "{count} непрочитаних коментарів",
    "Comment" : "Коментар",
    "<strong>Comments</strong> for files" : "<strong>Коментарі</strong> до файлів"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
