OC.L10N.register(
    "comments",
    {
    "Comments" : "Σχόλια",
    "Type in a new comment..." : "Αυτό είναι ένα νέο σχόλιο...",
    "Delete comment" : "Διαγραφή σχολίου",
    "Cancel" : "Άκυρο",
    "Edit comment" : "Επεξεργασία σχολίου",
    "More comments..." : "Περισσότερα σχόλια...",
    "Save" : "Αποθήκευση",
    "Comment" : "Σχόλιο"
},
"nplurals=2; plural=(n != 1);");
