OC.L10N.register(
    "comments",
    {
    "Cancel" : "එපා",
    "Save" : "සුරකින්න"
},
"nplurals=2; plural=(n != 1);");
