OC.L10N.register(
    "comments",
    {
    "<strong>Comments</strong> for files" : "<strong>Opombe</strong> datotek",
    "%1$s commented" : "%1$s opomb",
    "%1$s commented on %2$s" : "%1$s opomb ob %2$s",
    "Comments" : "Opombe",
    "Type in a new comment..." : "Vpis nove opombe ...",
    "Delete comment" : "Izbriši opombo",
    "Post" : "Objavi",
    "Cancel" : "Prekliči",
    "Edit comment" : "Uredi opombo",
    "[Deleted user]" : "[Izbrisan uporabnik]",
    "No other comments available" : "Ni drugih opomb",
    "More comments..." : "Več opomb ...",
    "Save" : "Shrani",
    "Allowed characters {count} of {max}" : "Dovoljeni znaki: {count} od {max}",
    "{count} unread comments" : "{count} neprebranih opomb",
    "Comment" : "Opomba",
    "<strong>Comments</strong> for files" : "<strong>Opombe</strong> datotek"
},
"nplurals=4; plural=(n%100==1 ? 0 : n%100==2 ? 1 : n%100==3 || n%100==4 ? 2 : 3);");
