OC.L10N.register(
    "comments",
    {
    "<strong>Comments</strong> for files" : "<strong>แสดงความคิดเห็น</strong> สำหรับไฟล์",
    "%1$s commented" : "%1$s ได้ถูกแสดงความคิดเห็น",
    "%1$s commented on %2$s" : "%1$s ได้ถูกแสดงความคิดเห็นบน %2$s",
    "Comments" : "ความคิดเห็น",
    "Type in a new comment..." : "พิมพ์ความคิดเห็นใหม่ ...",
    "Delete comment" : "ลบความคิดเห็น",
    "Post" : "โพสต์",
    "Cancel" : "ยกเลิก",
    "Edit comment" : "แก้ไขความคิดเห็น",
    "[Deleted user]" : "[ผู้ใช้ถูกลบไปแล้ว]",
    "Save" : "บันทึก",
    "Comment" : "แสดงความคิดเห็น",
    "<strong>Comments</strong> for files" : "<strong>แสดงความคิดเห็น</strong> สำหรับไฟล์"
},
"nplurals=1; plural=0;");
