OC.L10N.register(
    "comments",
    {
    "%1$s commented" : "%1$s коментиран",
    "Cancel" : "Откажи",
    "Save" : "Сними",
    "Comment" : "Коментар"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
