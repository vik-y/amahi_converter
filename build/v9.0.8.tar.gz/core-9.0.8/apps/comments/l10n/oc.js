OC.L10N.register(
    "comments",
    {
    "Cancel" : "Anullar",
    "Save" : "Enregistrar",
    "Comment" : "Comentar"
},
"nplurals=2; plural=(n > 1);");
