OC.L10N.register(
    "comments",
    {
    "Cancel" : "취소",
    "Save" : "저장",
    "Comment" : "설명",
    "<strong>Comments</strong> for files" : "파일에 <strong>댓글</strong> 남기기",
    "Delete comment" : "댓글 삭제",
    "Edit comment" : "댓글 편집",
    "No other comments available" : "더 이상 댓글 없음",
    "Post" : "게시"
},
"nplurals=1; plural=0;");
