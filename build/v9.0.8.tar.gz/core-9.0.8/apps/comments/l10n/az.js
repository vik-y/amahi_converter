OC.L10N.register(
    "comments",
    {
    "Cancel" : "Dayandır",
    "Save" : "Saxla",
    "Comment" : "Komentariya"
},
"nplurals=2; plural=(n != 1);");
