OC.L10N.register(
    "comments",
    {
    "Cancel" : "रद्द करें ",
    "Save" : "सहेजें"
},
"nplurals=2; plural=(n != 1);");
