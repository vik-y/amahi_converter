OC.L10N.register(
    "comments",
    {
    "<strong>Comments</strong> for files" : "<strong>Komentoj</strong> por dosieroj",
    "%1$s commented" : "%1$s komentis",
    "%1$s commented on %2$s" : "%1$s komentis %2$s",
    "Comments" : "Komentoj",
    "Type in a new comment..." : "Tajpu novan komenton...",
    "Delete comment" : "Forigi komenton",
    "Post" : "Afiŝi",
    "Cancel" : "Nuligi",
    "Edit comment" : "Redakti komenton",
    "[Deleted user]" : "[Forigita uzanto]",
    "No other comments available" : "Neniu alia komento disponeblas",
    "More comments..." : "Pli da komentoj...",
    "Save" : "Konservi",
    "Allowed characters {count} of {max}" : "Permesataj karakteroj: {count} el {max}",
    "{count} unread comments" : "{count} nelegitaj komentoj",
    "Comment" : "Komento",
    "<strong>Comments</strong> for files" : "<strong>Komentoj</strong> por dosieroj"
},
"nplurals=2; plural=(n != 1);");
