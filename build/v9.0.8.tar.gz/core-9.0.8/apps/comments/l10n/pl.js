OC.L10N.register(
    "comments",
    {
    "Cancel" : "Anuluj",
    "Save" : "Zapisz",
    "Comment" : "Komentarz",
    "<strong>Comments</strong> for files" : "<strong>Komentarze</strong> dla plików",
    "Delete comment" : "Skasuj komentarz",
    "Edit comment" : "Edytuj komentarz",
    "No other comments available" : "Nie ma więcej komentarzy",
    "Post" : "Zapisz"
},
"nplurals=3; plural=(n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
