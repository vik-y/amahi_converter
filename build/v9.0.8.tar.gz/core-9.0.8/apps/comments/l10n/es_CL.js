OC.L10N.register(
    "comments",
    {
    "Cancel" : "Cancelar"
},
"nplurals=2; plural=(n != 1);");
