OC.L10N.register(
    "comments",
    {
    "Cancel" : "Atšaukti",
    "Save" : "Išsaugoti",
    "Comment" : "Komentaras"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && (n%100<10 || n%100>=20) ? 1 : 2);");
