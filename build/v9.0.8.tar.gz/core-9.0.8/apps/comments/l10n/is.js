OC.L10N.register(
    "comments",
    {
    "Cancel" : "Hætta við",
    "Save" : "Vista",
    "Comment" : "Athugasemd",
    "<strong>Comments</strong> for files" : "<strong>Athugasemdir</strong> við skrár",
    "Delete comment" : "Eyða athugasemd",
    "Edit comment" : "Breyta athugasemd",
    "No other comments available" : "Engar aðrar athugasemdir eru tiltækar",
    "Post" : "Senda"
},
"nplurals=2; plural=(n % 10 != 1 || n % 100 == 11);");
