OC.L10N.register(
    "comments",
    {
    "Cancel" : "Cancel·la",
    "Save" : "Desa",
    "Comment" : "Comentari"
},
"nplurals=2; plural=(n != 1);");
