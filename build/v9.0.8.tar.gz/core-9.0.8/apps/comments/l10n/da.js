OC.L10N.register(
    "comments",
    {
    "Cancel" : "Annullér",
    "Save" : "Gem",
    "Comment" : "Kommentér"
},
"nplurals=2; plural=(n != 1);");
