OC.L10N.register(
    "comments",
    {
    "<strong>Comments</strong> for files" : "<strong>Komentar</strong> untuk berkas",
    "%1$s commented" : "%1$s dikomentari",
    "%1$s commented on %2$s" : "%1$s dikomentari pada %2$s",
    "Comments" : "Komentar",
    "Type in a new comment..." : "Ketik di komentar baru...",
    "Delete comment" : "Hapus komentar",
    "Post" : "Posting",
    "Cancel" : "Batal",
    "Edit comment" : "Sunting komentar",
    "[Deleted user]" : "[Hapus pengguna]",
    "No other comments available" : "Tidak ada komentar lainnya",
    "More comments..." : "Komentar lainya...",
    "Save" : "Simpan",
    "Allowed characters {count} of {max}" : "Karakter yang diizinkan {count} dari {max}",
    "{count} unread comments" : "{count} komentar belum dibaca",
    "Comment" : "Komentar",
    "<strong>Comments</strong> for files" : "<strong>Komentar</strong> untuk berkas"
},
"nplurals=1; plural=0;");
