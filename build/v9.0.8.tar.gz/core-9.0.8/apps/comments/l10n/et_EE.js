OC.L10N.register(
    "comments",
    {
    "%1$s commented on %2$s" : "%1$s kommenteeris %2$s",
    "Comments" : "Kommentaarid",
    "Type in a new comment..." : "Kirjuta uus komentaar...",
    "Delete comment" : "Kustuta kommentaar",
    "Post" : "Postita",
    "Cancel" : "Loobu",
    "Edit comment" : "Muuda kommentaari",
    "[Deleted user]" : "[Kustutatud kasutaja]",
    "No other comments available" : "Ühtegi teist kommentaari pole saadaval",
    "More comments..." : "Veel kommentaare...",
    "Save" : "Salvesta",
    "Allowed characters {count} of {max}" : "Lubatud märkide arv {count}/{max}",
    "{count} unread comments" : "{count} lugemata kommentaari",
    "Comment" : "Kommentaar"
},
"nplurals=2; plural=(n != 1);");
