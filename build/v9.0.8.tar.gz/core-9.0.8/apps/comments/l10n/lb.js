OC.L10N.register(
    "comments",
    {
    "Cancel" : "Ofbriechen",
    "Save" : "Späicheren"
},
"nplurals=2; plural=(n != 1);");
