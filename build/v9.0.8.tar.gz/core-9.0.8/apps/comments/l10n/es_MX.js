OC.L10N.register(
    "comments",
    {
    "Cancel" : "Cancelar",
    "Save" : "Guardar",
    "Comment" : "Comentario"
},
"nplurals=2; plural=(n != 1);");
