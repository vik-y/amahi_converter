OC.L10N.register(
    "comments",
    {
    "Cancel" : "Одустани",
    "Save" : "Сачувај",
    "Comment" : "Коментар",
    "<strong>Comments</strong> for files" : "<strong>Коментари</strong> фајлова",
    "Delete comment" : "Обриши коментар",
    "Edit comment" : "Уреди коментар",
    "No other comments available" : "Нема других коментара",
    "Post" : "Објави"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
