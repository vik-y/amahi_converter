OC.L10N.register(
    "comments",
    {
    "Cancel" : "منصرف شدن",
    "Save" : "ذخیره",
    "Comment" : "نظر"
},
"nplurals=1; plural=0;");
