OC.L10N.register(
    "comments",
    {
    "Cancel" : "Kanselleer"
},
"nplurals=2; plural=(n != 1);");
